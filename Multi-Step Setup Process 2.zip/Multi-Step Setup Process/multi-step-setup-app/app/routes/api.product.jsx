import { authenticate } from "../shopify.server";

export const loader = async ({ request }) => {
  const { admin } = await authenticate.admin(request);
  console.log("=========================product getting called");

  const response = await admin.graphql(
    `query GetProducts {
      products(first: 50) {
        edges {
          node {
            id
            title
            featuredImage {
              url
            }
            totalInventory
            variants(first: 50) {
              edges {
                node {
                  id
                  price
                  sku
                  inventoryItem {
                    id
                  }
                }
              }
            }
          }
        }
      }
    }`,
  );

  const data = await response.json();

  const products = data.data.products.edges.map(({ node }) => {
    const variants =
      node.variants?.edges?.map(({ node: v }) => ({
        variantId: v.id,
        sku: v.sku,
        inventoryItemId: v.inventoryItem?.id || null,
        stock: node.totalInventory,
      })) ?? [];

    return {
      id: node.id,
      title: node.title,
      image: node.featuredImage?.url || null,
      stock: node.totalInventory,
      price:
        variants[0]?.price || node.variants?.edges?.[0]?.node?.price || "0.00",
      sku: variants[0]?.sku || node.variants?.edges?.[0]?.node?.sku || null,
      variants,
    };
  });

  console.log(
    "Products returned from /api/product (with variants):",
    JSON.stringify(products, null, 2),
  );

  return new Response(JSON.stringify(products), {
    headers: { "Content-Type": "application/json" },
  });
};
