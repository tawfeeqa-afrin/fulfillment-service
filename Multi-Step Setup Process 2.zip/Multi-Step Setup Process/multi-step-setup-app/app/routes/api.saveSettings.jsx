import { authenticate } from "../shopify.server";
import prisma from "../db.server";
export const action = async ({ request }) => {
  console.log("called the saved backend");
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const { products } = await request.json();
  console.log(
    "products list from backend to save prisma==============",
    products,
  );
  for (const product of products) {
    console.log("product id-===========", product.productId);
  }
  const shopData = await prisma.shop.findUnique({
    where: { shop },
    select: {
      fulfillmentServiceId: true,
      fulfillmentServiceLocationId: true,
    },
  });
  const fulfillmentServiceId = shopData?.fulfillmentServiceId;
  const fulfillmentServiceLocationId = shopData?.fulfillmentServiceLocationId;

  console.log("shop FFS data========", fulfillmentServiceId);
  console.log("shop FFS location data========", fulfillmentServiceLocationId);
  if (!fulfillmentServiceId || !fulfillmentServiceLocationId) {
    return new Response(
      JSON.stringify({
        success: false,
        error: "Fulfillment service not configured. Complete Step 1 first.",
      }),
      { status: 400 },
    );
  }

  try {
    for (const product of products) {
      if (!Array.isArray(product.variants)) continue;

      for (const variant of product.variants) {
        if (!variant.inventoryItemId) continue;

        //activate inventory
        await admin.graphql(
          `
      mutation InventoryActivate($inventoryItemId: ID!, $locationId: ID!) {
        inventoryActivate(
          inventoryItemId: $inventoryItemId
          locationId: $locationId
        ) {
          inventoryLevel { id }
          userErrors { message }
        }
      }
      `,
          {
            variables: {
              inventoryItemId: variant.inventoryItemId,
              locationId: fulfillmentServiceLocationId,
            },
          },
        );

        /* 2️⃣ SET INVENTORY */
        const setInventory = await admin.graphql(
          `
  #graphql
  mutation inventorySetQuantities($input: InventorySetQuantitiesInput!) {
    inventorySetQuantities(input: $input) {
      inventoryAdjustmentGroup {
        reason
        changes {
          name
          quantityAfterChange
        }
      }
      userErrors {
        code
        message
      }
    }
  }
  `,
          {
            variables: {
              input: {
                reason: "correction",
                name: "available",
                ignoreCompareQuantity: true,
                quantities: [
                  {
                    inventoryItemId: variant.inventoryItemId,
                    locationId: fulfillmentServiceLocationId,
                    quantity: product.stock ?? 0,
                  },
                ],
              },
            },
          },
        );
        const inventoryResult = await setInventory.json();

        console.log("product stock=======", product.stock);
        console.log(
          "set inventory========",
          JSON.stringify(inventoryResult, null, 2),
        );

        //save to prisma
        await prisma.savedProductInfo.upsert({
          where: {
            shop_productId: {
              shop,
              productId: product.productId,
            },
          },
          update: {
            title: product.title,
            image: product.image,
            price: product.price,
            stock: product.stock ?? 0,
            sku: product.sku,
            inventoryItemId: variant.inventoryItemId,
          },
          create: {
            shop,
            productId: product.productId,
            title: product.title,
            image: product.image,
            price: product.price,
            stock: product.stock ?? 0,
            sku: product.sku,
            inventoryItemId: variant.inventoryItemId,
            fulfillmentServiceId,
          },
        });
      }
    }

    await prisma.shop.update({
      where: { shop },
      data: { stepCompleted: 2 },
    });
    return new Response(JSON.stringify({ success: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (Err) {
    console.log("failed to save in prisma=====>", Err);
    return new Response(
      JSON.stringify({ success: false, error: Err.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      },
    );
  }
};
