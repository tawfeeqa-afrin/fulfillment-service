import { authenticate } from "../shopify.server";
import prisma from "../db.server";
export const action = async ({ request }) => {
  console.log("backend called");
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;

  //===============CARRIER SERVICE ============================================
  const carrierServiceResponse = await admin.graphql(
    `mutation CarrierServiceCreate($input: DeliveryCarrierServiceCreateInput!) {
  carrierServiceCreate(input: $input) {
    carrierService {
      id
      name
      callbackUrl
      active
      supportsServiceDiscovery
    }
    userErrors {
      field
      message
    }
  }
}`,
    {
      variables: {
        input: {
          name: "carrier-service",
          callbackUrl:
            "https://bisectional-stateliest-nataly.ngrok-free.dev/carrier-service",
          supportsServiceDiscovery: true,
          active: true,
        },
      },
    },
  );
  const result = await carrierServiceResponse.json();
  const payload = result.data?.carrierServiceCreate;
  let carrierServiceId = payload?.carrierService?.id;
  //=================GET CARRIER SERVICE ID===============
  if (!carrierServiceId) {
    console.log("Carrier service already exists. Fetching...");
    const fetchResponse = await admin.graphql(`
      query {
        carrierServices(first: 50) {
          edges {
            node {
              id
              name
            }
          }
        }
      }
    `);

    const fetchResult = await fetchResponse.json();
    console.log("fetchResult =======", fetchResponse);
    const existing = fetchResult.data.carrierServices.edges.find(
      (edge) => edge.node.name === "carrier-service",
    );

    if (!existing) {
      throw new Error("Carrier service not found");
    }

    carrierServiceId = existing.node.id;
  }
  console.log("Final carrierServiceId========", carrierServiceId);

  //====================  FULLFILLMENT SERVICE====================
  const fulfillmentResponse = await admin.graphql(
    `
      mutation FulfillmentServiceCreate($name: String!, $callbackUrl: URL!) {
        fulfillmentServiceCreate(name: $name, callbackUrl: $callbackUrl) {
          fulfillmentService {
            id
            serviceName
            callbackUrl
          }
          userErrors {
            field
            message
          }
        }
      }
    `,
    {
      variables: {
        name: "fullfillment-service",
        callbackUrl:
          "https://bisectional-stateliest-nataly.ngrok-free.dev/fullfillment-service",
      },
    },
  );
  const fulfillmentJson = await fulfillmentResponse.json();
  const fulfillmentPayload = fulfillmentJson.data?.fulfillmentServiceCreate;
  let fulfillmentServiceId = fulfillmentPayload?.fulfillmentService?.id || null;
  const fulfillmentErrors = fulfillmentPayload?.userErrors || [];
  console.log("fulfillmentServiceCreate payload:", fulfillmentPayload);
  //======================GET FULLFILLMENT SERVICE ID====================
  if (!fulfillmentServiceId) {
    console.log("FFS already exists. Fetching...");
    const listResponse = await admin.graphql(
      `
      query FulfillmentServiceList {
        shop {
          fulfillmentServices {
            id
            callbackUrl
            serviceName
          }
        }
      }
    `,
    );
    const listJson = await listResponse.json();
    const services = listJson.data?.shop?.fulfillmentServices || [];

    console.log(
      "Fulfillment services list:",
      JSON.stringify(services, null, 2),
    );
    const existingFullfillment = services.find(function (service) {
      return service.serviceName === "fullfillment-service";
    });

    if (!existingFullfillment) {
      throw new Error("fullfillment service not found");
    }

    fulfillmentServiceId = existingFullfillment.id;
  }
  console.log(
    "fullfiment service id after fetch===========",
    fulfillmentServiceId,
  );
  //========================GET FULLFILLMENT SERVICE LOCATION ID ===================
  let fulfillmentServiceLocationId = null;

  if (fulfillmentServiceId) {
    const ffsLocationResp = await admin.graphql(
      `
        query GetFulfillmentServiceLocation($id: ID!) {
          fulfillmentService(id: $id) {
            id
            serviceName
            location {
              id
              name
            }
          }
        }
      `,
      {
        variables: {
          id: fulfillmentServiceId,
        },
      },
    );

    const ffsLocationJson = await ffsLocationResp.json();
    fulfillmentServiceLocationId =
      ffsLocationJson.data?.fulfillmentService?.location?.id || null;

    console.log(
      "Fulfillment service location data:",
      JSON.stringify(ffsLocationJson.data, null, 2),
    );

    if (!fulfillmentServiceLocationId) {
      console.log(
        "Fulfillment service location not found for",
        fulfillmentServiceId,
      );
    }
  } else {
    console.log("No fulfillmentServiceId, skipping location fetch");
  }

  console.log(
    "Fulfillment service location id ==========",
    fulfillmentServiceLocationId,
  );

  //========================ORDER CREATE=======================
  const webhookResponse = await admin.graphql(
    `
      mutation webhookSubscriptionCreate($topic: WebhookSubscriptionTopic!, $webhookSubscription: WebhookSubscriptionInput!) {
    webhookSubscriptionCreate(topic: $topic, webhookSubscription: $webhookSubscription) {
      webhookSubscription {
        id
        topic
        uri
      }
      userErrors {
        field
        message
      }
    }
  }
    `,

    {
      variables: {
        topic: "ORDERS_CREATE",
        webhookSubscription: {
          uri: "https://bisectional-stateliest-nataly.ngrok-free.dev/order-create",
          includeFields: [
            "id",
            "admin_graphql_api_id",
            "name",
            "customer",
            "line_items",
            "shipping_address",
          ],
        },
      },
    },
  );

  const json = await webhookResponse.json();

  let orderWebhookId =
    json.data.webhookSubscriptionCreate.webhookSubscription?.id;

  console.log(
    "webhook Res=======",
    json.data?.webhookSubscriptionCreate?.userErrors,
  );
  console.log("webhook id=======", orderWebhookId);

  //==========GET ORDER CREATED WEBHOOK ID=================
  if (!orderWebhookId) {
    console.log("order create webhook already exists");
    const webhookResponse = await admin.graphql(
      `
       query {
    webhookSubscriptions(first: 50) {
      edges {
        node {
          id
          topic
          uri
          includeFields
        }
      }
    }
  }

      `,
    );
    const webhookListJson = await webhookResponse.json();

    const edges = webhookListJson.data?.webhookSubscriptions?.edges ?? [];

    console.log("Existing webhookSubscriptions:", edges);

    console.log(
      "Existing webhookSubscriptions>>>>>:",
      JSON.stringify(edges, null, 2),
    );
    const existingWebhook = edges.find(function (edge) {
      return edge.node.topic === "ORDERS_CREATE";
    });

    orderWebhookId = existingWebhook.node.id;
    const orderWebhookIncludeFields = existingWebhook.node.includeFields;
    console.log("include Fields =================", orderWebhookIncludeFields);
  }
  console.log("order-create webhook id after fetch===========", orderWebhookId);

  
  try {
    await prisma.shop.upsert({
      where: {
        shop: shop,
      },
      update: {
        stepCompleted: 1,
        carrierServiceId: carrierServiceId,
        fulfillmentServiceId: fulfillmentServiceId,
        fulfillmentServiceLocationId: fulfillmentServiceLocationId,
        orderWebhookId: orderWebhookId,
      },
      create: {
        shop: shop,
        stepCompleted: 1,
        carrierServiceId: carrierServiceId,
        fulfillmentServiceId: fulfillmentServiceId,
        fulfillmentServiceLocationId: fulfillmentServiceLocationId,
        orderWebhookId: orderWebhookId,
      },
    });
  } catch (Err) {
    console.log("Failed to save in prisma", Err);
  }

  return new Response(
    JSON.stringify({
      success: true,
      carrierServiceId,
      fulfillmentServiceId,
      fulfillmentServiceLocationId,
      orderWebhookId,
    }),
    { headers: { "Content-Type": "application/json" } },
  );
};
