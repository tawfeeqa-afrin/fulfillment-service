import prisma from "../db.server";
import { authenticate } from "../shopify.server";

export async function syncOrdersAndGetFromPrisma(request) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  console.log("calledd============");

  const shopData = await prisma.shop.findUnique({
    where: { shop },
    select: { fulfillmentServiceLocationId: true },
  });

  const MY_LOCATION_ID = shopData?.fulfillmentServiceLocationId;
  if (!MY_LOCATION_ID) throw new Error("FFS location not found");

  const ordersResp = await admin.graphql(`
  query {
    orders(first: 20) {
      nodes {
        id
        name
        fulfillmentOrders(first: 10) {
          nodes {
            id
            lineItems(first: 250) {
              nodes {
                id
                inventoryItemId
                remainingQuantity
              }
            }
          }
        }
        lineItems(first: 250) {
          nodes {
            name
            quantity
            sku
            variant {
              inventoryItem {
                id
              }
            }
          }
        }
      }
    }
  }
`);

  const ordersJson = await ordersResp.json();
  const orders = ordersJson.data.orders.nodes;

  console.log("ALL ORDERS:");
  console.log(JSON.stringify(orders, null, 2));

  // Get inventory stocked at FFS location
  const inventoryResp = await admin.graphql(
    `
    query ($locationId: ID!) {
      inventoryItems(first: 250) {
        nodes {
          id
          sku
          inventoryLevel(locationId: $locationId) {
            location { id name }
            quantities(names: ["available"]) {
              quantity
            }
          }
        }
      }
    }
    `,
    { variables: { locationId: MY_LOCATION_ID } },
  );

  const inventoryJson = await inventoryResp.json();
  const inventoryItems = inventoryJson.data.inventoryItems.nodes;

  //  Build lookup map (inventoryItemId → availability)
  const inventoryMap = new Map();

  for (const item of inventoryItems) {
    if (!item.inventoryLevel) continue;

    const available =
      item.inventoryLevel.quantities.find((q) => q.quantity > 0)?.quantity ?? 0;

    if (available > 0) {
      inventoryMap.set(item.id, {
        sku: item.sku,
        available,
        locationName: item.inventoryLevel.location.name,
      });
    }
  }

  //  Match orders → FFS inventory
  const result = [];

  for (const order of orders) {
    const matchedLineItems = [];

    for (const li of order.lineItems.nodes) {
      const inventoryItemId = li.variant?.inventoryItem?.id;

      if (!inventoryItemId) continue;
      if (!inventoryMap.has(inventoryItemId)) continue;

      matchedLineItems.push({
        name: li.name,
        sku: li.sku,
        quantity: li.quantity,
        inventoryItemId,
        location: inventoryMap.get(inventoryItemId).locationName,
        available: inventoryMap.get(inventoryItemId).available,
      });
    }

    if (matchedLineItems.length > 0) {
      result.push({
        orderId: order.id,
        orderName: order.name,
        lineItems: matchedLineItems,
      });
    }
  }

  console.log("FFS FILTERED ORDERS:================");
  console.log(JSON.stringify(result, null, 2));

  //  Move FFS items to FFS location
  const orderFOMap = {};

  for (const order of orders) {
    for (const fo of order.fulfillmentOrders.nodes) {
      const moveLineItems = [];

      for (const li of fo.lineItems.nodes) {
        if (inventoryMap.has(li.inventoryItemId)) {
          moveLineItems.push({
            id: li.id,
            quantity: li.remainingQuantity,
          });
        }
      }

      if (moveLineItems.length === 0) continue;

      // console.log(" Moving Fulfillment Order:", fo.id);

      const moveFOResRaw = await admin.graphql(
        `
      mutation fulfillmentOrderMove(
        $id: ID!,
        $newLocationId: ID!,
        $lineItems: [FulfillmentOrderLineItemInput!]!
      ) {
        fulfillmentOrderMove(
          id: $id,
          newLocationId: $newLocationId,
          fulfillmentOrderLineItems: $lineItems
        ) {
          movedFulfillmentOrder {
            id
            assignedLocation {
              name
            }
          }
          userErrors {
            field
            message
          }
        }
      }
      `,
        {
          variables: {
            id: fo.id,
            newLocationId: MY_LOCATION_ID,
            lineItems: moveLineItems,
          },
        },
      );

      const moveFORes = await moveFOResRaw.json();

      const movedFOId =
        moveFORes.data?.fulfillmentOrderMove?.movedFulfillmentOrder?.id;
      if (movedFOId) {
        orderFOMap[order.id] = movedFOId; 
        // console.log("Moved FO ID:", movedFOId);
      } else {
        console.log(
          "Failed to move FO:",
          moveFORes.data.fulfillmentOrderMove.userErrors,
        );
      }
    }
  }

  //  Save filtered orders in Prisma
  for (const order of result) {
    const movedFOId = orderFOMap[order.orderId] || null;
    // console.log("movedFOId===========", movedFOId);
    await prisma.orders.upsert({
      where: { shopifyOrderId: order.orderId },
      update: {
        orderName: order.orderName,
        ...(movedFOId && { fulfillmentOrderId: movedFOId }),

        lineItems: {
          deleteMany: {
            orderShopifyId: order.orderId,
          },
          create: order.lineItems.map((li) => ({
            inventoryItemId: li.inventoryItemId,
            name: li.name,
            sku: li.sku ?? "",
            quantity: li.quantity,
            available: li.available,
            location: li.location,
          })),
        },
      },
      create: {
        shopifyOrderId: order.orderId,
        orderName: order.orderName,
        fulfillmentOrderId: movedFOId,
        lineItems: {
          create: order.lineItems.map((li) => ({
            inventoryItemId: li.inventoryItemId,
            name: li.name,
            sku: li.sku ?? "",
            quantity: li.quantity,
            available: li.available,
            location: li.location,
          })),
        },
      },
    });
  }

  console.log("Orders saved in Prisma");

  return prisma.orders.findMany({
    include: { lineItems: true },
    orderBy: { createdAt: "desc" },
  });
}
