// app/routes/webhooks.order-created.jsx
import prisma from "../db.server";

export const action = async ({ request }) => {
  const order = await request.json();

  const orderGid = order.admin_graphql_api_id;
  const lineItems = order.line_items;
  console.log("order created");
  console.log(orderGid);
  console.log(lineItems);

  // Process next steps here
  return new Response("OK");
};
