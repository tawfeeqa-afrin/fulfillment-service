/*
  Warnings:

  - You are about to drop the column `shopDomain` on the `Shop` table. All the data in the column will be lost.
  - Added the required column `shop` to the `Shop` table without a default value. This is not possible if the table is not empty.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Shop" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "shop" TEXT NOT NULL,
    "carrierServiceId" TEXT,
    "fulfillmentServiceId" TEXT,
    "orderWebhookId" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "new_Shop" ("carrierServiceId", "createdAt", "fulfillmentServiceId", "id", "orderWebhookId") SELECT "carrierServiceId", "createdAt", "fulfillmentServiceId", "id", "orderWebhookId" FROM "Shop";
DROP TABLE "Shop";
ALTER TABLE "new_Shop" RENAME TO "Shop";
CREATE UNIQUE INDEX "Shop_shop_key" ON "Shop"("shop");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
