/*
  Warnings:

  - The primary key for the `SavedProductInfo` table will be changed. If it partially fails, the table could be left without primary key constraint.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_SavedProductInfo" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "shop" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "image" TEXT,
    "price" TEXT NOT NULL,
    "stock" INTEGER NOT NULL,
    "fulfillmentServiceId" TEXT NOT NULL
);
INSERT INTO "new_SavedProductInfo" ("fulfillmentServiceId", "id", "image", "price", "productId", "shop", "stock", "title") SELECT "fulfillmentServiceId", "id", "image", "price", "productId", "shop", "stock", "title" FROM "SavedProductInfo";
DROP TABLE "SavedProductInfo";
ALTER TABLE "new_SavedProductInfo" RENAME TO "SavedProductInfo";
CREATE UNIQUE INDEX "SavedProductInfo_shop_productId_key" ON "SavedProductInfo"("shop", "productId");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
