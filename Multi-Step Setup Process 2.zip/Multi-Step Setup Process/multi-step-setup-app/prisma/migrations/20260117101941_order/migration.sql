/*
  Warnings:

  - You are about to drop the column `orderId` on the `LineItem` table. All the data in the column will be lost.
  - The primary key for the `Order` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id` on the `Order` table. All the data in the column will be lost.
  - Added the required column `orderShopifyId` to the `LineItem` table without a default value. This is not possible if the table is not empty.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_LineItem" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "orderShopifyId" TEXT NOT NULL,
    "inventoryItemId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "sku" TEXT NOT NULL,
    "variantId" TEXT,
    "quantity" INTEGER NOT NULL,
    "available" INTEGER NOT NULL,
    "location" TEXT NOT NULL,
    "price" REAL,
    "fulfillmentStatus" TEXT,
    CONSTRAINT "LineItem_orderShopifyId_fkey" FOREIGN KEY ("orderShopifyId") REFERENCES "Order" ("shopifyOrderId") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_LineItem" ("available", "fulfillmentStatus", "id", "inventoryItemId", "location", "name", "price", "quantity", "sku", "variantId") SELECT "available", "fulfillmentStatus", "id", "inventoryItemId", "location", "name", "price", "quantity", "sku", "variantId" FROM "LineItem";
DROP TABLE "LineItem";
ALTER TABLE "new_LineItem" RENAME TO "LineItem";
CREATE TABLE "new_Order" (
    "shopifyOrderId" TEXT NOT NULL PRIMARY KEY,
    "orderName" TEXT NOT NULL,
    "customerName" TEXT,
    "customerEmail" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "financialStatus" TEXT,
    "fulfillmentStatus" TEXT
);
INSERT INTO "new_Order" ("createdAt", "customerEmail", "customerName", "financialStatus", "fulfillmentStatus", "orderName", "shopifyOrderId") SELECT "createdAt", "customerEmail", "customerName", "financialStatus", "fulfillmentStatus", "orderName", "shopifyOrderId" FROM "Order";
DROP TABLE "Order";
ALTER TABLE "new_Order" RENAME TO "Order";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
