/*
  Warnings:

  - You are about to drop the `Orders` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "Orders";
PRAGMA foreign_keys=on;

-- CreateTable
CREATE TABLE "Order" (
    "shopifyOrderId" TEXT NOT NULL PRIMARY KEY,
    "orderName" TEXT NOT NULL,
    "customerName" TEXT,
    "customerEmail" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "financialStatus" TEXT,
    "fulfillmentStatus" TEXT
);

-- CreateTable
CREATE TABLE "LineItem" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "orderShopifyId" TEXT NOT NULL,
    "inventoryItemId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "sku" TEXT NOT NULL,
    "variantId" TEXT,
    "quantity" INTEGER NOT NULL,
    "available" INTEGER NOT NULL,
    "location" TEXT NOT NULL,
    "price" REAL,
    "fulfillmentStatus" TEXT,
    CONSTRAINT "LineItem_orderShopifyId_fkey" FOREIGN KEY ("orderShopifyId") REFERENCES "Order" ("shopifyOrderId") ON DELETE RESTRICT ON UPDATE CASCADE
);
