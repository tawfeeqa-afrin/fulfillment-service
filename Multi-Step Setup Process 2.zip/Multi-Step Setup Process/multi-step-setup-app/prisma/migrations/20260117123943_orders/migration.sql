/*
  Warnings:

  - You are about to drop the `LineItem` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `lineItemsJson` to the `Orders` table without a default value. This is not possible if the table is not empty.

*/
-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "LineItem";
PRAGMA foreign_keys=on;

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Orders" (
    "shopifyOrderId" TEXT NOT NULL PRIMARY KEY,
    "orderName" TEXT NOT NULL,
    "customerName" TEXT,
    "customerEmail" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "financialStatus" TEXT,
    "fulfillmentStatus" TEXT,
    "lineItemsJson" JSONB NOT NULL
);
INSERT INTO "new_Orders" ("createdAt", "customerEmail", "customerName", "financialStatus", "fulfillmentStatus", "orderName", "shopifyOrderId") SELECT "createdAt", "customerEmail", "customerName", "financialStatus", "fulfillmentStatus", "orderName", "shopifyOrderId" FROM "Orders";
DROP TABLE "Orders";
ALTER TABLE "new_Orders" RENAME TO "Orders";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
