/*
  Warnings:

  - You are about to drop the column `lineItemsJson` on the `Orders` table. All the data in the column will be lost.

*/
-- CreateTable
CREATE TABLE "LineItem" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "orderShopifyId" TEXT NOT NULL,
    "inventoryItemId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "sku" TEXT NOT NULL,
    "variantId" TEXT,
    "quantity" INTEGER NOT NULL,
    "available" INTEGER NOT NULL,
    "location" TEXT NOT NULL,
    "price" REAL,
    "fulfillmentStatus" TEXT,
    CONSTRAINT "LineItem_orderShopifyId_fkey" FOREIGN KEY ("orderShopifyId") REFERENCES "Orders" ("shopifyOrderId") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Orders" (
    "shopifyOrderId" TEXT NOT NULL PRIMARY KEY,
    "orderName" TEXT NOT NULL,
    "customerName" TEXT,
    "customerEmail" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "financialStatus" TEXT,
    "fulfillmentStatus" TEXT
);
INSERT INTO "new_Orders" ("createdAt", "customerEmail", "customerName", "financialStatus", "fulfillmentStatus", "orderName", "shopifyOrderId") SELECT "createdAt", "customerEmail", "customerName", "financialStatus", "fulfillmentStatus", "orderName", "shopifyOrderId" FROM "Orders";
DROP TABLE "Orders";
ALTER TABLE "new_Orders" RENAME TO "Orders";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
