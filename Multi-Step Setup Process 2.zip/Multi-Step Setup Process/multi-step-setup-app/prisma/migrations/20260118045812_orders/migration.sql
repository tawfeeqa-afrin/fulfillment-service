/*
  Warnings:

  - You are about to drop the column `fulfillmentStatus` on the `LineItem` table. All the data in the column will be lost.
  - You are about to drop the column `price` on the `LineItem` table. All the data in the column will be lost.
  - You are about to drop the column `variantId` on the `LineItem` table. All the data in the column will be lost.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_LineItem" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "orderShopifyId" TEXT NOT NULL,
    "inventoryItemId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "sku" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "available" INTEGER NOT NULL,
    "location" TEXT NOT NULL,
    CONSTRAINT "LineItem_orderShopifyId_fkey" FOREIGN KEY ("orderShopifyId") REFERENCES "Orders" ("shopifyOrderId") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_LineItem" ("available", "id", "inventoryItemId", "location", "name", "orderShopifyId", "quantity", "sku") SELECT "available", "id", "inventoryItemId", "location", "name", "orderShopifyId", "quantity", "sku" FROM "LineItem";
DROP TABLE "LineItem";
ALTER TABLE "new_LineItem" RENAME TO "LineItem";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
