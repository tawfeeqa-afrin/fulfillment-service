/*
  Warnings:

  - You are about to drop the column `fulfillmentOrderId` on the `Orders` table. All the data in the column will be lost.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Orders" (
    "shopifyOrderId" TEXT NOT NULL PRIMARY KEY,
    "orderName" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "new_Orders" ("createdAt", "orderName", "shopifyOrderId") SELECT "createdAt", "orderName", "shopifyOrderId" FROM "Orders";
DROP TABLE "Orders";
ALTER TABLE "new_Orders" RENAME TO "Orders";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
