import express from "express";
import cors from "cors";
const app = express();
app.use(express.json());
console.log("server is running");
app.use(
  cors({
    origin: "*",
    methods: ["GET", "POST", "OPTIONS"],
    allowedHeaders: ["Content-Type"],
  }),
);
app.get("/", async (req, res) => {
  return res.send("helloo !!!!!");
});
app.post("/inventory", async (req, res) => {
  console.log("Inventory API called");
  console.log("Request body:", req.body);
  const sku = req.body.sku;
  console.log("sku=====", sku);
  const skuLength = sku.length;
  console.log("skuLenght==", skuLength);
  const inventoryCount = skuLength * 2;
  console.log(inventoryCount);

  res.status(200).json({ success: true, sku, inventoryCount });
});

app.post("/carrier-service", async (req, res) => {
  console.log("carrier-service called");
  try {
    const { rate } = req.body;
    console.log(">>====rate", rate);
    if (!rate || !rate.items) {
      return res.status(200).json({ rates: [] });
    }

    // Count total quantity
    const totalItems = rate.items.reduce((sum, item) => sum + item.quantity, 0);
    console.log("total products==========", totalItems);
    let rates = [];

    if (totalItems === 1) {
      rates.push({
        service_name: "Standard Delivery",
        service_code: "STANDARD",
        total_price: "0",
        currency: "USD",
        description: "Delivered in 4 days",
        min_delivery_date: new Date(Date.now() + 4 * 86400000).toISOString(),
        max_delivery_date: new Date(Date.now() + 4 * 86400000).toISOString(),
      });
    }

    if (totalItems === 2) {
      rates.push(
        {
          service_name: "Standard Delivery",
          service_code: "STANDARD",
          total_price: "0",
          currency: "USD",
          description: "Delivered in 4 days",
        },
        {
          service_name: "Moderate Delivery",
          service_code: "MODERATE",
          total_price: "500",
          currency: "USD",
          description: "Delivered in 2 days",
        },
      );
    }

    if (totalItems > 2) {
      rates.push(
        {
          service_name: "Standard Delivery",
          service_code: "STANDARD",
          total_price: "0",
          currency: "USD",
        },
        {
          service_name: "Moderate Delivery",
          service_code: "MODERATE",
          total_price: "500",
          currency: "USD",
        },
        {
          service_name: "Fast Delivery",
          service_code: "FAST",
          total_price: "1000",
          currency: "USD",
          description: "Next-day delivery",
        },
      );
    }

    return res.status(200).json({ rates });
  } catch (err) {
    console.error("Carrier service error:", err);
    return res.status(500).json({ rates: [] });
  }
});

app.post("/request-fullfillment", async (req, res) => {
  console.log("fullfillment service called");
  const { lineItems, orderId } = req.body;
  console.log(orderId, "==orderid");
  console.log(lineItems, "lineitem");
  const trackingUrl = `https://tracking.example.com/${orderId}`;
  const carrierInfo = {
    carrier: "carrier-rate",
    shipmentId: `SHIP-${orderId}`,
    estimatedDelivery: "2026-01-20",
  };

  res.status(200).json({
    success: true,
    trackingUrl,
    carrierInfo,
  });
});

app.post("/order-create", async (req, res) => {
  console.log("order create called");
  console.log("order created");
  try {
    const order = req.body;
    console.log("order received:", order.id);
    console.log("order details----", order);
  } catch (Err) {
    console.log("order webhook error:", Err);
    return res.status(200).send("Webhook error");
  }
});
// app.post("/request-fullfillment", async (req, res) => {
//   const { orderId, lineItems } = req.body;
//   console.log("request fullfillment called====");

//   const normalizedOrderId = orderId.startsWith("gid://")
//     ? orderId
//     : `gid://shopify/Order/${orderId}`;

//   try {
//     // 1️⃣ Get fulfillment orders
//     const foRes = await admin.graphql(`
//       query {
//         order(id: "${normalizedOrderId}") {
//           fulfillmentOrders(first: 10) {
//             nodes {
//               id
//               status
//             }
//           }
//         }
//       }
//     `);

//     const foJson = await foRes.json();
//     const fulfillmentOrders =
//       foJson?.data?.order?.fulfillmentOrders?.nodes || [];

//     if (!fulfillmentOrders.length) {
//       return res.status(400).json({
//         success: false,
//         error: "No fulfillment order created by Shopify yet",
//       });
//     }

//     const fulfillmentOrder = fulfillmentOrders[0];

//     // 2️⃣ ACCEPT fulfillment request (🔥 REQUIRED 🔥)
//     if (fulfillmentOrder.status === "OPEN") {
//       const acceptRes = await admin.graphql(`
//         mutation {
//           fulfillmentOrderAccept(id: "${fulfillmentOrder.id}") {
//             fulfillmentOrder {
//               id
//               status
//             }
//             userErrors {
//               message
//             }
//           }
//         }
//       `);

//       const acceptJson = await acceptRes.json();
//       const errors = acceptJson?.data?.fulfillmentOrderAccept?.userErrors || [];

//       if (errors.length) {
//         return res.status(400).json({
//           success: false,
//           error: "Failed to accept fulfillment request",
//           details: errors,
//         });
//       }
//     }

//     // 3️⃣ Return carrier + tracking info
//     return res.json({
//       success: true,
//       trackingUrl: `https://tracking.example.com/${normalizedOrderId}`,
//       carrierInfo: {
//         carrier: "carrier-rate",
//         shipmentId: `SHIP-${normalizedOrderId}`,
//         estimatedDelivery: "2026-01-20",
//       },
//     });
//   } catch (err) {
//     console.error(err);
//     return res.status(500).json({
//       success: false,
//       error: "Internal server error",
//     });
//   }
// });

const port = 8000;
app.listen(port, () => {
  console.log(`server is listening on the port ${port}`);
});
