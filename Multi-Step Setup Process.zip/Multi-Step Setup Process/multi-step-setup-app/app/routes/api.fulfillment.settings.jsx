import { authenticate } from "../shopify.server";
export const action = async ({ request }) => {
  console.log("🚀 fulfill-order API called");
  console.log("Request URL:", new URL(request.url).pathname);
  console.log("Request method:", request.method);
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const { orderId, trackingUrl, carrier, fulfillmentServiceLocationId } =
    await request.json();
  console.log("orderId====", orderId);

  if (!orderId || !trackingUrl || !carrier) {
    return new Response(
      JSON.stringify({
        success: false,
        error: "Missing orderId, trackingUrl, or carrier",
      }),
      { status: 400 },
    );
  }

  //  Normalize Order ID to GID format
  const normalizedOrderId = orderId.startsWith("gid://")
    ? orderId
    : `gid://shopify/Order/${orderId}`;

  const numericOrderId = normalizedOrderId.split("/").pop();

  try {
    console.log(
      "Using fulfillment location from Prisma:",
      fulfillmentServiceLocationId,
    );

    //  Fetch Fulfillment Orders using location + order filters

    const numericLocationId = fulfillmentServiceLocationId.split("/").pop();

    const foSearchQuery = `assigned_location_id:${numericLocationId} order_id:${numericOrderId}`;
    console.log("foSearch Query===========", foSearchQuery);
    const foRes = await admin.graphql(
      `
       
        query FulfillmentOrdersByOrder($query: String!, $first: Int!) {
  fulfillmentOrders(first: $first, query: $query) {
    nodes {
      id
      status
      order {
        id
        name
      }
      assignedLocation {
        location {
          id
          name
        }
      }
    }
  }
}
      `,
      {
        variables: {
          query: foSearchQuery,
          first: 10,
        },
      },
    );

    const foJson = await foRes.json();
    console.log(
      " FulfillmentOrdersByLocation raw:",
      JSON.stringify(foJson, null, 2),
    );

    const fulfillmentOrders = foJson?.data?.fulfillmentOrders?.nodes || [];

    console.log("Fulfillment Orders parsed:", fulfillmentOrders);

    if (!fulfillmentOrders.length) {
      return new Response(
        JSON.stringify({
          success: false,
          error:
            "No fulfillment order found for this order and location. Ensure routing has assigned the order to this fulfillment service location.",
        }),
        { status: 400 },
      );
    }

    const fulfillmentOrder = fulfillmentOrders[0];

    console.log(
      "Using fulfillmentOrder:",
      fulfillmentOrder.id,
      "status:",
      fulfillmentOrder.status,
      "order:",
      fulfillmentOrder.order?.id,
      "assignedLocation:",
      fulfillmentOrder.assignedLocation?.location?.id,
    );

    // Create Fulfillment with Tracking using fulfillmentCreate

    const fulfillRes = await admin.graphql(
      `
        mutation CreateFulfillment(
          $fulfillmentOrderId: ID!
          $trackingUrl: URL!
          $trackingCompany: String!
        ) {
          fulfillmentCreate(
            fulfillment: {
              lineItemsByFulfillmentOrder: {
                fulfillmentOrderId: $fulfillmentOrderId
              }
              trackingInfo: {
                url: $trackingUrl
                company: $trackingCompany
              }
              notifyCustomer: true
            }
          ) {
            fulfillment {
              id
              status
            }
            userErrors {
              field
              message
            }
          }
        }
      `,
      {
        variables: {
          fulfillmentOrderId: fulfillmentOrder.id,
          trackingUrl,
          trackingCompany: carrier,
        },
      },
    );

    const fulfillJson = await fulfillRes.json();
    console.log(
      " fulfillmentCreate response:",
      JSON.stringify(fulfillJson, null, 2),
    );

    const fulfillPayload = fulfillJson?.data?.fulfillmentCreate;
    const fulfillErrors = fulfillPayload?.userErrors || [];

    if (fulfillErrors.length) {
      return new Response(
        JSON.stringify({
          success: false,
          error: "Failed to create fulfillment",
          details: fulfillErrors,
        }),
        { status: 400 },
      );
    }

    console.log("Order fulfilled successfully");

    //  SUCCESS

    return new Response(
      JSON.stringify({
        success: true,
        message: "Order fulfilled successfully in Shopify",
        fulfillmentId: fulfillPayload.fulfillment?.id,
        status: fulfillPayload.fulfillment?.status,
      }),
      { status: 200 },
    );
  } catch (error) {
    console.error("Fulfillment error:", error);

    return new Response(
      JSON.stringify({
        success: false,
        error: "Internal server error",
      }),
      { status: 500 },
    );
  }
};
