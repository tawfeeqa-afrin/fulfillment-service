import { authenticate } from "../shopify.server";

export const loader = async ({ request }) => {
  const { admin } = await authenticate.admin(request);
  console.log("=========================product getting called");

  const response = await admin.graphql(
    `query GetProducts {
      products(first: 50) {
        edges {
          node {
            id
            title
            featuredImage {
              url
            }
            totalInventory
            
            variants(first: 1) {
              edges {
                node {
                  price
                  sku
                }
              }
            }
          }
        }
      }
    }`,
  );

  const data = await response.json();
  // console.log("data from product API========", data);
  // console.log("get product data array====", data.data.products.edges);

  const products = data.data.products.edges.map(({ node }) => ({
    id: node.id,
    title: node.title,
    image: node.featuredImage?.url || null,
    stock: node.totalInventory,
    price: node.variants.edges[0]?.node.price || "0.00",
    sku: node.variants.edges[0]?.node.sku || null,
  }));

  return new Response(JSON.stringify(products));
};
