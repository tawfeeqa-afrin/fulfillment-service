import { authenticate } from "../shopify.server";
import prisma from "../db.server";
export const action = async ({ request }) => {
  console.log("product remove api is called====");
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;

  const { productId } = await request.json();
  console.log("==========product id from remove product file====", productId);
  if (!productId) {
    return new Response({ error: "Product id is required" }, { status: 400 });
  }
  try {
    const res = await prisma.savedProductInfo.deleteMany({
      where: {
        shop,
        productId,
      },
    });
    console.log(
      "response from prisma for deletion====",
      JSON.stringify(res, null, 2),
    );
    console.log("delete count=====", res.count);
    console.log("existing products in DB=====", res);
    console.log("incoming productId=====", productId);
    console.log("productID=========", productId);
    return new Response({ success: true });
  } catch (Err) {
    console.log("error for remove product from backend api file=====", Err);
    return new Response({ success: false, error: "failed to remove" });
  }
};
