import prisma from "../db.server";
import { authenticate } from "../shopify.server";
export const action = async ({ request }) => {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const { productId, inventory } = await request.json();
  const product = await prisma.savedProductInfo.findUnique({
    where: {
      shop_productId: {
        shop,
        productId,
      },
    },
  });
  const shopData = await prisma.shop.findUnique({
    where: { shop },
    select: { fulfillmentServiceLocationId: true },
  });

  if (!shopData?.fulfillmentServiceLocationId) {
    return new Response("Location not configured", { status: 400 });
  }

  const inventoryItemId = product.inventoryItemId;
  const locationId = shopData.fulfillmentServiceLocationId;
  console.log("location id=======", locationId);
  console.log("inventoryItem id====", inventoryItemId);

 
  const updateInventory = await admin.graphql(
    `
    
    mutation inventorySetQuantities($input: InventorySetQuantitiesInput!) {
      inventorySetQuantities(input: $input) {
        inventoryAdjustmentGroup {
          reason
          changes {
            name
            quantityAfterChange
          }
        }
        userErrors {
          code
          message
        }
      }
    }
    `,
    {
      variables: {
        input: {
          reason: "correction",
          name: "available",
          ignoreCompareQuantity: true,
          quantities: [
            {
              inventoryItemId,
              locationId,
              quantity: inventory,
             
            },
          ],
        },
      },
    },
  );

  const inventoryResult = await updateInventory.json();

  console.log("inventory after multiply=======", inventory);
  console.log(
    "update  inventory========",
    JSON.stringify(inventoryResult, null, 2),
  );
  await prisma.savedProductInfo.update({
    where: {
      shop_productId: {
        shop,
        productId,
      },
    },
    data: {
      stock: inventory,
    },
  });

  return new Response(JSON.stringify({ success: true }), { status: 200 });
};
