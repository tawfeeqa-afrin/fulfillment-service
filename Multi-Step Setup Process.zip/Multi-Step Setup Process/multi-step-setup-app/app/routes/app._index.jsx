import { authenticate } from "../shopify.server";
import prisma from "../db.server";
import { useNavigate } from "react-router";
import { useLoaderData } from "react-router";
import { useState } from "react";
import { AppProvider } from "@shopify/shopify-app-react-router/react";
export const loader = async ({ request }) => {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const shopData = await prisma.shop.upsert({
    where: { shop },
    update: {},
    create: { shop, stepCompleted: 0 },
  });
  const stepCompleted = shopData.stepCompleted;
  console.log(
    " step completed from index file==========",
    shopData.stepCompleted,
  );
  return stepCompleted;
};

export default function Index() {
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const stepComplete = useLoaderData();
  console.log(stepComplete, "stepComplete from the function in index file");
  // useEffect(() => {
  //   if (stepComplete === 1) {
  //     navigate("/productPage");
  //   } else if (stepComplete >= 2) {
  //     navigate("/dashboardPage");
  //   }
  // }, [stepComplete, navigate]);

  const step1 = async () => {
    try {
      console.log("button clicksss");
      setLoading(true);
      const res = await fetch("/api/step1/settings", {
        method: "POST",
        headers: { "content-Type": "application/json" },
      });
      const data = await res.json();
      console.log("response========", data);
      if (data.success) {
        navigate("/productPage");
      }
    } catch (err) {
      console.log("failed to fetch step 1 API", err);
    }
  };
  return (
    <AppProvider>
      <s-page>
        <s-section>
          <s-heading>Service Setup</s-heading>
          <ul>
            <li>Create a Carrier Services</li>
            <li>Create a Fulfillment Service</li>
            <li>Register an Order Created Webhook</li>
          </ul>

          <s-button variant="primary" onClick={step1} disabled={loading}>
            {loading ? (
              <s-spinner accessibilityLabel="Loading" size="small" />
            ) : (
              "Continue"
            )}
          </s-button>
        </s-section>
      </s-page>
    </AppProvider>
  );
}
