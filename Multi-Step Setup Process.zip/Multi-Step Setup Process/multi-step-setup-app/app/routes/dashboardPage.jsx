import { useNavigate } from "react-router";
import { AppProvider } from "@shopify/shopify-app-react-router/react";

export default function Dashboard() {
  const navigate = useNavigate();
  return (
    <AppProvider>
      <s-page>
        <s-section>
          <s-heading>Welcome to Dashboard page</s-heading>
          <s-app-nav>
            <s-link href="/dashboardPageProducts">Products</s-link>
            <s-link href="/dashboardPageOrders">Orders</s-link>
          </s-app-nav>
          <s-button onClick={() => navigate("/dashboardPageProducts")}>
            View Product
          </s-button>
          <s-button onClick={() => navigate("/dashboardPageOrders")}>
            View Orders
          </s-button>
        </s-section>
      </s-page>
    </AppProvider>
  );
}
