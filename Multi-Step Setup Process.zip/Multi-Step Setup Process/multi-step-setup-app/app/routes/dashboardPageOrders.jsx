import { useLoaderData } from "react-router";
import { syncOrdersAndGetFromPrisma } from "./orders";
import { AppProvider } from "@shopify/shopify-app-react-router/react";
import { authenticate } from "../shopify.server";
import prisma from "../db.server";

// ===== Loader runs on server =====
export const loader = async ({ request }) => {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  console.log("session=====", session);
  console.log("shop===", shop);

  const orders = await syncOrdersAndGetFromPrisma(request);
  const dbShop = await prisma.shop.findUnique({
    where: { shop },
    select: { fulfillmentServiceLocationId: true },
  });

  if (!dbShop?.fulfillmentServiceLocationId) {
    throw new Response("Fulfillment service location not found", {
      status: 400,
    });
  }

  console.log("shopLocation====", dbShop.fulfillmentServiceLocationId);

  return new Response(
    JSON.stringify({
      orders,
      fulfillmentServiceLocationId: dbShop.fulfillmentServiceLocationId,
    }),
    {
      status: 200,
      headers: { "Content-Type": "application/json" },
    },
  );
};

// ===== Client Component =====
export default function Orders() {
  const { orders, fulfillmentServiceLocationId } = useLoaderData();
  console.log(orders);

  const requestFulfillment = async (order) => {
    if (order.lineItems.length <= 1) {
      alert("Cannot request fulfillment for orders with only 1 item");
      return;
    }
    try {
      console.log(order.shopifyOrderId, "===orderiddd");
      const res = await fetch(
        "https://bisectional-stateliest-nataly.ngrok-free.dev/request-fullfillment",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            orderId: order.shopifyOrderId,
            lineItems: order.lineItems.map((li) => ({
              inventoryItemId: li.inventoryItemId,
              name: li.name,
              sku: li.sku,
              quantity: li.quantity,
            })),
          }),
        },
      );

      const data = await res.json();
      console.log("data====", JSON.stringify(data, null, 2));
      console.log("success data", data.success);
      if (data.success) {
        try {
          const res = await fetch("/api/fulfillment/settings", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              orderId: order.shopifyOrderId,
              trackingUrl: data.trackingUrl,
              carrier: data.carrierInfo.carrier,
              shipmentId: data.carrierInfo.shipmentId,
              fulfillmentServiceLocationId,
            }),
          });
          console.log("res.status", res.status);

          if (!res.ok) {
            const text = await res.text();
            console.log("Fetch failed with:", res.status, text);
            throw new Error("Fetch failed");
          }

          const result = await res.json();
          console.log("result=====", result);
          console.log("Fetch success:", result);
        } catch (err) {
          console.log("error in fetching:", err);
        }

        alert("Order fulfilled successfully in Shopify!");
        console.log("Carrier & shipment info:", data.carrierInfo);
      } else {
        alert("Failed to fulfill order.");
      }
    } catch (err) {
      console.error("Fulfill order error:", err);
      alert("Error fulfilling order.");
    }
  };

  return (
    <AppProvider>
      <s-page>
        <s-section>
          <s-heading>Welcome to Orders page</s-heading>
          {/* <button onClick={saveOrders}>Save Orders</button> */}
          <div>
            <h1>FFS Orders</h1>
            {orders.map((order) => (
              <div
                key={order.shopifyOrderId}
                style={{ border: "1px solid #ccc", padding: 10, margin: 10 }}
              >
                <p>Order: {order.orderName}</p>
                <p>Items: {order.lineItems.length}</p>
                <s-button
                  variant="primary"
                  onClick={() => requestFulfillment(order)}
                >
                  Request Fulfillment
                </s-button>
              </div>
            ))}
          </div>
        </s-section>
      </s-page>
    </AppProvider>
  );
}
