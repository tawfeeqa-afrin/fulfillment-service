import styles from "./styles/styles.module.css";
import { authenticate } from "../shopify.server";
import prisma from "../db.server";
import { useLoaderData } from "react-router";
import { useState } from "react";
import { AppProvider } from "@shopify/shopify-app-react-router/react";
export const loader = async ({ request }) => {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;

  const savedProducts = await prisma.savedProductInfo.findMany({
    where: { shop },
  });
  const shopData = await prisma.shop.findUnique({
    where: { shop },
  });
  const stepCompleted = shopData.stepCompleted;
  console.log("step Completed from dashboardPage", stepCompleted);

  return { savedProducts };
};
export default function DashboardProduct() {
  const { savedProducts: initialSavedProducts } = useLoaderData();
  const [savedProducts, setSavedProducts] = useState(initialSavedProducts);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState([]);

  const availableProducts = products.filter(
    (product) => !savedProducts.some((saved) => saved.productId === product.id),
  );
  const updateInventory = async (product) => {
    console.log("update button clicked==", product);
    try {
      const res = await fetch(
        "https://bisectional-stateliest-nataly.ngrok-free.dev/inventory",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            sku: product.sku,
          }),
        },
      );
      const data = await res.json();
      console.log("Response from Node server:", data);
      const { inventoryCount } = data;
      await fetch("/api/updateInventory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: product.productId,
          inventory: inventoryCount,
        }),
      });

      alert(`Inventory updated to ${inventoryCount}`);

      if (!res.ok) {
        throw new Error("Inventory update failed");
      }
    } catch (err) {
      console.error("Inventory error:", err);
      alert("Failed to call inventory API");
    }
  };

  const handleRemoveProduct = async (productId) => {
    console.log("remove button clicked", productId);
    try {
      const res = await fetch("/api/removeProduct", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ productId }),
      });

      setSavedProducts((prev) =>
        prev.filter((product) => product.productId !== productId),
      );
    } catch (err) {
      console.log("error in deleting..........", err);
    }
  };

  const loadProducts = async () => {
    console.log("onclick loadproducts");
    try {
      console.log("try");
      setLoading(true);
      const res = await fetch("/api/product");
      console.log(res, "=====res");
      if (!res.ok) {
        throw new Error(`Request failed with status ${res.status}`);
      }
      const data = await res.json();
      console.log("fetched data=============>>>>", data);
      setProducts(data);
      setLoading(false);
    } catch (err) {
      console.log("error in fetching=========", err);
    }
  };
  const handleSave = async () => {
    if (selected.length === 0) {
      alert("Select at least one product");
      return;
    }

    const normalized = selected.map((p) => ({
      productId: p.id,
      title: p.title,
      image: p.image,
      price: p.price,
      stock: p.stock,
      sku: p.sku,
    }));

    const res = await fetch("/api/saveSettings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ products: normalized }),
    });

    if (res.ok) {
      const newlyAdded = selected;

      setSavedProducts((prev) => [...prev, ...newlyAdded]);
      setSelected([]);
      alert("Products added");
    }
  };
  return (
    <AppProvider>
      <s-page>
        <s-section>
          <s-heading>Welcome to Product page</s-heading>
          <ul>
            {savedProducts.map((product) => (
              <li key={product.id} className={styles.addedProductList}>
                <img
                  src={product.image}
                  alt={product.title}
                  className={styles.productImg}
                />

                <span>{product.title}</span>
                <p>{product.sku}</p>

                <s-button
                  size="slim"
                  variant="destructive"
                  onClick={() => handleRemoveProduct(product.productId)}
                >
                  Remove
                </s-button>
                <s-button
                  size="slim"
                  variant="primary"
                  onClick={() => updateInventory(product)}
                >
                  Update Inventory
                </s-button>
              </li>
            ))}
          </ul>
          <s-button
            commandFor="product-modal"
            variant="primary"
            onClick={loadProducts}
          >
            Add Products
          </s-button>
          <s-modal id="product-modal" heading="Select Product">
            <s-modal-header>
              <s-heading>Add Products</s-heading>
            </s-modal-header>

            <s-modal-body>
              <s-box className={styles.productListBox}>
                {loading && <s-text>Loading...</s-text>}

                {!loading &&
                  availableProducts.map((product) => (
                    <s-box key={product.id}>
                      <div className={styles.productList}>
                        <input
                          type="checkbox"
                          checked={selected.some((p) => p.id === product.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelected((prev) => [...prev, product]);
                            } else {
                              setSelected((prev) =>
                                prev.filter((p) => p.id !== product.id),
                              );
                            }
                          }}
                        />
                        {product.image && (
                          <img
                            src={product.image}
                            alt={product.title}
                            className={styles.productImg}
                          />
                        )}
                        <div>
                          <div className={styles.productTitle}>
                            {product.title}
                          </div>
                          <div className={styles.productStock}>
                            {product.stock} available
                          </div>
                        </div>
                        <span className={styles.productPrice}>
                          ${product.price}
                        </span>
                      </div>
                    </s-box>
                  ))}
              </s-box>
            </s-modal-body>

            <s-modal-footer>
              <s-button
                slot="secondary-actions"
                commandFor="product-modal"
                command="--hide"
              >
                Cancel
              </s-button>
              <s-button variant="primary" onClick={handleSave}>
                Add
              </s-button>
            </s-modal-footer>
          </s-modal>
        </s-section>
      </s-page>
    </AppProvider>
  );
}
