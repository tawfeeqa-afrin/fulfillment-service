import { useState, useEffect } from "react";
import { useLoaderData } from "react-router";
import styles from "./styles/styles.module.css";
import { authenticate } from "../shopify.server";
import prisma from "../db.server";
import { useNavigate } from "react-router";
import { AppProvider } from "@shopify/shopify-app-react-router/react";
export const loader = async ({ request }) => {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const response = await admin.graphql(
    `query GetProducts {
      products(first: 50) {
        edges {
          node {
            id
            title
            featuredImage {
              url
            }
            totalInventory
            variants(first: 1) {
              edges {
                node {
                  price
                  sku
                  inventoryItem {
                    id
                  }
                }
              }
            }
          }
        }
      }
    }`,
  );

  const data = await response.json();
  console.log("data from product API========", data);

  const products = data.data.products.edges.map(({ node }) => ({
    id: node.id,
    title: node.title,
    image: node.featuredImage?.url || null,
    stock: node.totalInventory,
    price: node.variants.edges[0]?.node.price || "0.00",
    sku: node.variants.edges[0]?.node.sku || null,
  }));
  console.log("get product data array====", products);
  const productVariants = {};
  for (const { node } of data.data.products.edges) {
    const variants =
      node.variants?.edges?.map(({ node: v }) => ({
        variantId: v.id,
        sku: v.sku,
        price: v.price,
        inventoryItemId: v.inventoryItem?.id || null,
        stock: node.totalInventory,
      })) ?? [];

    productVariants[node.id] = variants;
  }
  console.log("productvariants======", productVariants);
  const savedProducts = await prisma.savedProductInfo.findMany({
    where: { shop },
  });
  const shopData = await prisma.shop.findUnique({
    where: { shop },
  });
  const stepCompleted = shopData.stepCompleted;
  console.log("step Completed from productPage", stepCompleted);

  return { products, productVariants, savedProducts, stepCompleted };
};

export default function Index() {
  const { products, productVariants, savedProducts, stepCompleted } =
    useLoaderData();
  const [selectedProducts, setSelectedProducts] = useState(savedProducts || []);
  const [tempSelectedProducts, setTempSelectedProducts] = useState([]);
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("Available Product");
  console.log(
    "step completed from the function in product file ===",
    stepCompleted,
  );
  // useEffect(() => {
  //   if (stepCompleted < 1) {
  //     navigate("/");
  //   } else if (stepCompleted >= 2) {
  //     navigate("/dashboardPage");
  //   }
  // }, [stepCompleted, navigate]);
  const handleSave = async (productToSave) => {
    console.log("handle calledd========", productToSave);
    if (!productToSave || productToSave.length === 0) {
      alert("Select at least one product");
      return false;
    }

    const saveData = {
      products: productToSave,
    };
    console.log(
      "the product going to be save====",
      JSON.stringify(saveData, null, 2),
    );
    try {
      const res = await fetch("/api/saveSettings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(saveData),
      });
      const results = await res.json();
      if (!res.ok || !results.success) {
        alert("Failed to save products");
        return false;
      }

      alert("Saved successfully");
      return true;
    } catch (err) {
      console.log("failed to fetch=======", err);
      alert("Something went wrong");
      return false;
    }
  };
  const handleRemoveProduct = async (productId) => {
    try {
      const res = await fetch("/api/removeProduct", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ productId }),
      });

      setSelectedProducts((prev) =>
        prev.filter((product) => product.productId !== productId),
      );
    } catch (err) {
      console.log("error in deleting..........", err);
    }
  };
  const filteredProducts = products
    .filter((product) =>
      product.title.toLowerCase().includes(search.toLowerCase()),
    )
    .filter((product) => !selectedProducts.some((p) => p.id === product.id));
  console.log("products:", products, Array.isArray(products));

  return (
    <AppProvider>
      <s-page>
        <s-section>
          <s-heading>Welcome to Product Page</s-heading>
          {/* Tabs */}
          <s-box className={styles.modalBox}>
            <s-button
              variant={
                activeTab === "Available Product" ? "primary" : "secondary"
              }
              onClick={() => setActiveTab("Available Product")}
            >
              Available Product
            </s-button>
            <s-button
              variant={activeTab === "Added Products" ? "primary" : "secondary"}
              onClick={() => setActiveTab("Added Products")}
            >
              Added Products
            </s-button>
          </s-box>
          {activeTab === "Available Product" && (
            <>
              {/* Product List */}
              <s-box className={styles.productListBox}>
                {/* Tab Content */}
                <s-box>
                  {activeTab === "Available Product" && (
                    <>
                      {/* Search Bar */}
                      <s-text-field
                        placeholder="Search products"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className={styles.searchBar}
                      />

                      {/* Product List */}
                      <s-box className={styles.productListBox}>
                        {loading && <s-text>Loading products...</s-text>}

                        {!loading && filteredProducts.length === 0 && (
                          <s-text>No products found</s-text>
                        )}

                        {!loading &&
                          filteredProducts.map((product) => {
                            return (
                              <s-box key={product.id}>
                                <div className={styles.productList}>
                                  <input
                                    type="checkbox"
                                    checked={tempSelectedProducts.some(
                                      (p) => p.id === product.id,
                                    )}
                                    onChange={(e) => {
                                      if (e.target.checked) {
                                        setTempSelectedProducts((prev) => [
                                          ...prev,
                                          product,
                                        ]);
                                      } else {
                                        setTempSelectedProducts((prev) =>
                                          prev.filter(
                                            (p) => p.id !== product.id,
                                          ),
                                        );
                                      }
                                    }}
                                  />

                                  {product.image && (
                                    <img
                                      src={product.image}
                                      alt={product.title}
                                      className={styles.productImg}
                                    />
                                  )}
                                  <div>
                                    <div className={styles.productTitle}>
                                      {product.title}
                                    </div>
                                    <div className={styles.productStock}>
                                      {product.stock} available
                                    </div>
                                  </div>
                                  <span className={styles.productPrice}>
                                    ${product.price}
                                  </span>
                                </div>
                              </s-box>
                            );
                          })}
                      </s-box>
                    </>
                  )}
                </s-box>
              </s-box>
            </>
          )}

          {activeTab === "Added Products" && (
            <>
              <ul>
                {selectedProducts.map((product) => (
                  <li key={product.id} className={styles.addedProductList}>
                    <img
                      src={product.image}
                      alt={product.title}
                      className={styles.productImg}
                    />

                    <span>{product.title}</span>

                    <s-button
                      size="slim"
                      variant="destructive"
                      onClick={() => handleRemoveProduct(product.productId)}
                    >
                      Remove
                    </s-button>
                  </li>
                ))}
              </ul>
            </>
          )}
          {activeTab === "Available Product" && (
            <s-button
              variant="primary"
              onClick={async () => {
                const merged = [...selectedProducts, ...tempSelectedProducts];
                console.log("merged=============", merged);

                const normalized = tempSelectedProducts.map((p) => ({
                  productId: p.id,
                  title: p.title,
                  image: p.image,
                  price: p.price,
                  stock: p.stock,
                  sku: p.sku,
                  variants: (productVariants[p.id] || []).map((v) => ({
                    variantId: v.variantId,
                    sku: v.sku,
                    inventoryItemId: v.inventoryItemId,
                    stock: v.stock,
                  })),
                }));
                console.log(
                  "==========================>>>>>>>>>>>>.",
                  normalized,
                );

                const success = await handleSave(normalized);
                if (success) {
                  setSelectedProducts(merged);
                  setTempSelectedProducts([]);
                }
              }}
            >
              Add
            </s-button>
          )}
          <s-button
            onClick={() => {
              if (selectedProducts.length === 0) {
                alert("Select at least one product");
                return;
              }

              alert("You can continue");
              navigate("/dashboardPage");
            }}
          >
            Continue
          </s-button>
        </s-section>
      </s-page>
    </AppProvider>
  );
}
