-- CreateTable
CREATE TABLE "SavedProductInfo" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "shop" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "image" TEXT,
    "price" TEXT NOT NULL,
    "stock" INTEGER NOT NULL,
    "fulfillmentServiceId" TEXT NOT NULL
);
