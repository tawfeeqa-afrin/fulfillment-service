/*
  Warnings:

  - A unique constraint covering the columns `[shop,productId]` on the table `SavedProductInfo` will be added. If there are existing duplicate values, this will fail.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Shop" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "shop" TEXT NOT NULL,
    "stepCompleted" INTEGER NOT NULL DEFAULT 0,
    "carrierServiceId" TEXT,
    "fulfillmentServiceId" TEXT,
    "orderWebhookId" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "new_Shop" ("carrierServiceId", "createdAt", "fulfillmentServiceId", "id", "orderWebhookId", "shop") SELECT "carrierServiceId", "createdAt", "fulfillmentServiceId", "id", "orderWebhookId", "shop" FROM "Shop";
DROP TABLE "Shop";
ALTER TABLE "new_Shop" RENAME TO "Shop";
CREATE UNIQUE INDEX "Shop_shop_key" ON "Shop"("shop");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;

-- CreateIndex
CREATE UNIQUE INDEX "SavedProductInfo_shop_productId_key" ON "SavedProductInfo"("shop", "productId");
