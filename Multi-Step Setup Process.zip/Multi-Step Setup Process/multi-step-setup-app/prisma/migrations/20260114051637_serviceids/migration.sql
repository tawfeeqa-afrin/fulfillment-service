-- AlterTable
ALTER TABLE "Shop" ADD COLUMN "fulfillmentServiceLocationId" TEXT;
