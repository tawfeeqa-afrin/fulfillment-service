/*
  Warnings:

  - Added the required column `inventoryItemId` to the `SavedProductInfo` table without a default value. This is not possible if the table is not empty.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_SavedProductInfo" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "shop" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "image" TEXT,
    "price" TEXT NOT NULL,
    "stock" INTEGER NOT NULL,
    "sku" TEXT NOT NULL,
    "inventoryItemId" TEXT NOT NULL,
    "fulfillmentServiceId" TEXT NOT NULL
);
INSERT INTO "new_SavedProductInfo" ("fulfillmentServiceId", "id", "image", "price", "productId", "shop", "sku", "stock", "title") SELECT "fulfillmentServiceId", "id", "image", "price", "productId", "shop", "sku", "stock", "title" FROM "SavedProductInfo";
DROP TABLE "SavedProductInfo";
ALTER TABLE "new_SavedProductInfo" RENAME TO "SavedProductInfo";
CREATE UNIQUE INDEX "SavedProductInfo_shop_productId_key" ON "SavedProductInfo"("shop", "productId");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
